<?php

  $name = $_POST['name'];
  $lastname = $_POST['name'];

echo $name, $lastname;